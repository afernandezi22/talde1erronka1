var class_kokalekua_controller =
[
    [ "delete", "class_kokalekua_controller.html#a9d586641271527823eb70d2d748f1d02", null ],
    [ "gaurBainoBeranduago", "class_kokalekua_controller.html#a48046ef76b19704f4acf63962c1e6dd2", null ],
    [ "getAll", "class_kokalekua_controller.html#aba0d5b303383fb5b1fabb5fd01cd3800", null ],
    [ "getByFilter", "class_kokalekua_controller.html#a3794a39f0fd7530c6ecb2715a438a6ef", null ],
    [ "getById", "class_kokalekua_controller.html#a04a2ab5bf1980cc1c81cd541b6bb1ee7", null ],
    [ "getFreeEkipamendu", "class_kokalekua_controller.html#a60f1e3f6a0f6a0319b044fbc86f0421d", null ],
    [ "getZenbatPortatil", "class_kokalekua_controller.html#a775f664d2bc36d20d62e21c331a70317", null ],
    [ "post", "class_kokalekua_controller.html#a08c569c105bebfde1cbcad2a944ba5ab", null ],
    [ "put", "class_kokalekua_controller.html#ab50f9be74de1c2e2891866134fb5c178", null ]
];