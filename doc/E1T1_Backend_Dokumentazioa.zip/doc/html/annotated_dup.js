var annotated_dup =
[
    [ "Controller", "class_controller.html", "class_controller" ],
    [ "DB", "class_d_b.html", "class_d_b" ],
    [ "DefaultDB", "interface_default_d_b.html", "interface_default_d_b" ],
    [ "Ekipamendua", "class_ekipamendua.html", "class_ekipamendua" ],
    [ "EkipamenduaController", "class_ekipamendua_controller.html", "class_ekipamendua_controller" ],
    [ "Erabiltzailea", "class_erabiltzailea.html", "class_erabiltzailea" ],
    [ "ErabiltzaileaController", "class_erabiltzailea_controller.html", "class_erabiltzailea_controller" ],
    [ "Gela", "class_gela.html", "class_gela" ],
    [ "GelaController", "class_gela_controller.html", "class_gela_controller" ],
    [ "Inbentarioa", "class_inbentarioa.html", "class_inbentarioa" ],
    [ "InbentarioaController", "class_inbentarioa_controller.html", "class_inbentarioa_controller" ],
    [ "Kategoria", "class_kategoria.html", "class_kategoria" ],
    [ "KategoriaController", "class_kategoria_controller.html", "class_kategoria_controller" ],
    [ "Kokalekua", "class_kokalekua.html", "class_kokalekua" ],
    [ "KokalekuaController", "class_kokalekua_controller.html", "class_kokalekua_controller" ]
];