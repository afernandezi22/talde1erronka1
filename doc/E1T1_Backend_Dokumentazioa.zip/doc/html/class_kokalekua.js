var class_kokalekua =
[
    [ "__construct", "class_kokalekua.html#ac832cfdc364294d0133e0673252b023a", null ],
    [ "$amaieraData", "class_kokalekua.html#adeb4c72730b364ee9441725a72fe5b30", null ],
    [ "$ekipamenduIzena", "class_kokalekua.html#a9f5593c8d95a55152707bacbad339e82", null ],
    [ "$etiketa", "class_kokalekua.html#a48457ecbf6e44054b093d660f544dafe", null ],
    [ "$gelaIzena", "class_kokalekua.html#a6725d6beac2bdbd092ffe707525ac97f", null ],
    [ "$hasieraData", "class_kokalekua.html#a09132ad2c8c39acc9f96ab8b9d82f892", null ],
    [ "$idGela", "class_kokalekua.html#a862f11e393105197eb518acae6ca8958", null ]
];