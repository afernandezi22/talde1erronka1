var inbentarioacontroller_8php =
[
    [ "InbentarioaController", "class_inbentarioa_controller.html", "class_inbentarioa_controller" ]
];