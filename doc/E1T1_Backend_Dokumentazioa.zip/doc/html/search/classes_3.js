var searchData=
[
  ['gela_0',['Gela',['../class_gela.html',1,'']]],
  ['gelacontroller_1',['GelaController',['../class_gela_controller.html',1,'']]]
];
