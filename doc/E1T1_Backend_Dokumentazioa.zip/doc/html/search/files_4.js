var searchData=
[
  ['inbentarioa_2ephp_0',['inbentarioa.php',['../inbentarioa_8php.html',1,'']]],
  ['inbentarioacontroller_2ephp_1',['inbentarioacontroller.php',['../inbentarioacontroller_8php.html',1,'']]]
];
