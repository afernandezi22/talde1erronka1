var searchData=
[
  ['connect_0',['connect',['../class_d_b.html#a78572828d11dcdf2a498497d9001d557',1,'DB']]],
  ['controller_1',['Controller',['../class_controller.html',1,'']]],
  ['controller_2ephp_2',['controller.php',['../controller_8php.html',1,'']]]
];
