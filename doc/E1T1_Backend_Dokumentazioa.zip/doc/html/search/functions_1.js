var searchData=
[
  ['connect_0',['connect',['../class_d_b.html#a78572828d11dcdf2a498497d9001d557',1,'DB']]]
];
