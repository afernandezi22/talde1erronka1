var indexSectionsWithContent =
{
  0: "$_cdegiklps",
  1: "cdegik",
  2: "cdegik",
  3: "_cdeglps",
  4: "$"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

