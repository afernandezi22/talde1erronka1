var searchData=
[
  ['etiketasortu_0',['etiketaSortu',['../class_inbentarioa_controller.html#a3f7fb5fc0dd6e185c1cb49d82d35254d',1,'InbentarioaController']]]
];
