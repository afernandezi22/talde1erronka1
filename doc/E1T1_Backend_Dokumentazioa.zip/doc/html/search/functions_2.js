var searchData=
[
  ['delete_0',['delete',['../class_controller.html#a9d586641271527823eb70d2d748f1d02',1,'Controller\delete()'],['../class_ekipamendua_controller.html#a9d586641271527823eb70d2d748f1d02',1,'EkipamenduaController\delete()'],['../class_erabiltzailea_controller.html#a9d586641271527823eb70d2d748f1d02',1,'ErabiltzaileaController\delete()'],['../class_gela_controller.html#a9d586641271527823eb70d2d748f1d02',1,'GelaController\delete()'],['../class_inbentarioa_controller.html#a9d586641271527823eb70d2d748f1d02',1,'InbentarioaController\delete()'],['../class_kategoria_controller.html#a9d586641271527823eb70d2d748f1d02',1,'KategoriaController\delete()'],['../class_kokalekua_controller.html#a9d586641271527823eb70d2d748f1d02',1,'KokalekuaController\delete()']]],
  ['do_1',['do',['../class_d_b.html#a979a262ee2f358a9e11ecc236816ea5d',1,'DB\do()'],['../interface_default_d_b.html#a979a262ee2f358a9e11ecc236816ea5d',1,'DefaultDB\do()']]]
];
