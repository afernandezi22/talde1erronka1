var searchData=
[
  ['db_2ephp_0',['db.php',['../db_8php.html',1,'']]],
  ['defaultdb_2ephp_1',['defaultdb.php',['../defaultdb_8php.html',1,'']]]
];
