var class_kategoria =
[
    [ "__construct", "class_kategoria.html#ac593297bbce7a7ff23f163461aa343bc", null ],
    [ "$id", "class_kategoria.html#ae97941710d863131c700f069b109991e", null ],
    [ "$izena", "class_kategoria.html#aaf081aa8a8de3df65b0b4581fea1fe59", null ]
];