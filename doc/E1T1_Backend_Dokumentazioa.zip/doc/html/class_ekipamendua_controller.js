var class_ekipamendua_controller =
[
    [ "delete", "class_ekipamendua_controller.html#a9d586641271527823eb70d2d748f1d02", null ],
    [ "getAll", "class_ekipamendua_controller.html#aba0d5b303383fb5b1fabb5fd01cd3800", null ],
    [ "getByFilter", "class_ekipamendua_controller.html#a3794a39f0fd7530c6ecb2715a438a6ef", null ],
    [ "getById", "class_ekipamendua_controller.html#a04a2ab5bf1980cc1c81cd541b6bb1ee7", null ],
    [ "getByMarkaModelo", "class_ekipamendua_controller.html#a8c0d7a66ee6c6af4eb8fbfa8888728ca", null ],
    [ "post", "class_ekipamendua_controller.html#a08c569c105bebfde1cbcad2a944ba5ab", null ],
    [ "put", "class_ekipamendua_controller.html#ab50f9be74de1c2e2891866134fb5c178", null ]
];