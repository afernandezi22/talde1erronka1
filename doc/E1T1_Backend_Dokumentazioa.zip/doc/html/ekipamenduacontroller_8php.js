var ekipamenduacontroller_8php =
[
    [ "EkipamenduaController", "class_ekipamendua_controller.html", "class_ekipamendua_controller" ]
];