var kokalekuacontroller_8php =
[
    [ "KokalekuaController", "class_kokalekua_controller.html", "class_kokalekua_controller" ]
];