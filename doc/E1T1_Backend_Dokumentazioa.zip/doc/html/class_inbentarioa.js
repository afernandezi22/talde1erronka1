var class_inbentarioa =
[
    [ "__construct", "class_inbentarioa.html#aa35f18e0b85b08fabd449b6e7b1b7865", null ],
    [ "$erosketaData", "class_inbentarioa.html#ac90157093d3fc834e4ed867b688f4de8", null ],
    [ "$etiketa", "class_inbentarioa.html#a48457ecbf6e44054b093d660f544dafe", null ],
    [ "$idEkipamendu", "class_inbentarioa.html#ae36d541fa5142374e8d574a386a772c7", null ],
    [ "$izenaEkipamendu", "class_inbentarioa.html#a57fc02d8d54768e438a75c5410853dc4", null ]
];