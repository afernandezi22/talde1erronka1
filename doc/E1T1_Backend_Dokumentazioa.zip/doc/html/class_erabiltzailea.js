var class_erabiltzailea =
[
    [ "__construct", "class_erabiltzailea.html#a207e84705315f90c265f1c7e1a6d9727", null ],
    [ "$abizena", "class_erabiltzailea.html#af318e8cec2e2f16cbc2b1f74e14e5ea9", null ],
    [ "$erabiltzailea", "class_erabiltzailea.html#aedd6dc68b9fb70e0c2098fa60696e548", null ],
    [ "$irudia", "class_erabiltzailea.html#a94a373713bf42f116fdca147b30fb7bf", null ],
    [ "$izena", "class_erabiltzailea.html#aaf081aa8a8de3df65b0b4581fea1fe59", null ],
    [ "$nan", "class_erabiltzailea.html#a2c33b8facab3dd440c435674e93f29e8", null ],
    [ "$pasahitza", "class_erabiltzailea.html#aa11364fe1f83f934aa9886dd23bd405c", null ],
    [ "$rola", "class_erabiltzailea.html#a2004ca762ab847b16eb9f6addc89d286", null ]
];