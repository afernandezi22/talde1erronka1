var hierarchy =
[
    [ "Controller", "class_controller.html", [
      [ "EkipamenduaController", "class_ekipamendua_controller.html", null ],
      [ "ErabiltzaileaController", "class_erabiltzailea_controller.html", null ],
      [ "GelaController", "class_gela_controller.html", null ],
      [ "InbentarioaController", "class_inbentarioa_controller.html", null ],
      [ "KategoriaController", "class_kategoria_controller.html", null ],
      [ "KokalekuaController", "class_kokalekua_controller.html", null ]
    ] ],
    [ "DefaultDB", "interface_default_d_b.html", [
      [ "DB", "class_d_b.html", null ]
    ] ],
    [ "Ekipamendua", "class_ekipamendua.html", null ],
    [ "Erabiltzailea", "class_erabiltzailea.html", null ],
    [ "Gela", "class_gela.html", null ],
    [ "Inbentarioa", "class_inbentarioa.html", null ],
    [ "Kategoria", "class_kategoria.html", null ],
    [ "Kokalekua", "class_kokalekua.html", null ]
];