var kokalekua_8php =
[
    [ "Kokalekua", "class_kokalekua.html", "class_kokalekua" ]
];