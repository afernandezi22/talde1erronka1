var class_ekipamendua =
[
    [ "__construct", "class_ekipamendua.html#a8076e91551d90c61ed38286699eafe52", null ],
    [ "$deskribapena", "class_ekipamendua.html#a0b3d07fd030caea59defe59c4ab97eaa", null ],
    [ "$id", "class_ekipamendua.html#ae97941710d863131c700f069b109991e", null ],
    [ "$idKategoria", "class_ekipamendua.html#a2b0ce3b0596e19c9996d3b4947c2e9f3", null ],
    [ "$izena", "class_ekipamendua.html#aaf081aa8a8de3df65b0b4581fea1fe59", null ],
    [ "$kategoriaIzena", "class_ekipamendua.html#a31e241a6d5b54946b3eba4be07c0cd79", null ],
    [ "$marka", "class_ekipamendua.html#a3fe0064d7be5da0c6c128a69555fe39e", null ],
    [ "$modelo", "class_ekipamendua.html#a35947b45ef8bbedf6af105b39f44d718", null ],
    [ "$stock", "class_ekipamendua.html#ab704586a9573a6b31c9299104ddf4c78", null ]
];