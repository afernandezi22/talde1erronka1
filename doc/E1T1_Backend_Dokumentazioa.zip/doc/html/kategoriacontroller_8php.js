var kategoriacontroller_8php =
[
    [ "KategoriaController", "class_kategoria_controller.html", "class_kategoria_controller" ]
];