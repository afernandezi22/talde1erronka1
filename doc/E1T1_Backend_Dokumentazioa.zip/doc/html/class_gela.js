var class_gela =
[
    [ "__construct", "class_gela.html#a5792c9c27952fc7780b67aff6d2eaee4", null ],
    [ "getId", "class_gela.html#a12251d0c022e9e21c137a105ff683f13", null ],
    [ "$id", "class_gela.html#ae97941710d863131c700f069b109991e", null ],
    [ "$izena", "class_gela.html#aaf081aa8a8de3df65b0b4581fea1fe59", null ],
    [ "$taldea", "class_gela.html#a92ae671a8d5982b21ad940339b61563b", null ]
];